# cep-engagement-service

## Engagement Service for the client engagement portal

> SONAR BEFORE PUSH

```
mvn verify sonar:sonar
```

> This is the way to access Swagger UI

```
http://localhost:8080/swagger-ui.html#/
```

> To start the back-end application

```
java -jar target/cep-engagement-service-0.0.1-SNAPSHOT.jar
```

ALL DOCUMENTATION
https://drive.google.com/drive/folders/10wCBNKw3K1fegAQU771U0MYrsIdPa_fC?usp=sharing

> The below button is a collection from postman to simple test the Logic

[![Run in Postman](https://run.pstmn.io/button.svg)](https://app.getpostman.com/run-collection/aae80b6f3f8d9aa4c177)
