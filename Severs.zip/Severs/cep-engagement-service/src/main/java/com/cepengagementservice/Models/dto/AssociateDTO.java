package com.cepengagementservice.Models.dto;

import java.util.List;

import lombok.Data;

@Data
public class AssociateDTO {

    List<?> associate;
}