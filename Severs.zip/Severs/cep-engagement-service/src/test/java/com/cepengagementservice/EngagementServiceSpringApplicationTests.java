
package com.cepengagementservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EngagementServiceSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
